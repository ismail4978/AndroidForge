# Android phone se AURUM APK build karna

Is project mein GitHub Actions workflow shamil hai. GitHub ke cloud runner par APK build hogi; PC ki zaroorat nahi.

## Steps
1. ZIP ko phone par download karke extract karein.
2. GitHub account banayein/sign in karein: https://github.com
3. GitHub par **New repository** banayein. Naam `AurumIntelligence` rakh sakte hain; Public ya Private aapki marzi.
4. Repository ke **Add file → Upload files** se ZIP ke andar ka tamam project content upload karein. Hidden `.github` folder aur uske andar `workflows/build-apk.yml` bhi upload hona zaroori hai. Agar mobile browser hidden files nahi dikhata, GitHub website par browser ka **Desktop site** mode on karein.
5. Upload ke baad repository mein **Actions** tab kholein.
6. **Build AURUM Android APK** workflow select karein, phir **Run workflow** dabayein.
7. Build complete hone par run ke neeche **Artifacts** mein `aurum-intelligence-debug-apk` download karein.
8. ZIP artifact extract karein. `app-debug.apk` ko phone par tap karke install karein. Android agar permission maange to sirf GitHub se download ki hui apni APK ke liye install permission allow karein.

## Zaroori baat
- Yeh debug APK hogi, Play Store release-signed APK nahi.
- GitHub account aur internet zaroori hain. Main aapke GitHub account mein login, repository upload, ya cloud build trigger nahi kar sakta.
- Yeh build sirf v0.3 source ko compile karegi. Ismein live Exness connection, automatic AI chart vision, permanent database, ya real trade execution shamil nahi.
