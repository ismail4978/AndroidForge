package com.aurum.intelligence

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.abs

private val Gold = Color(0xFFD6AD55)
private val Dark = Color(0xFF101419)
private val Panel = Color(0xFF1A222B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AurumApp() }
    }
}

data class Candle(val time: String, val open: Double, val high: Double,
                  val low: Double, val close: Double, val volume: Double?)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AurumApp() {
    var tab by remember { mutableStateOf(0) }
    var screenshotUri by remember { mutableStateOf<Uri?>(null) }
    var csvName by remember { mutableStateOf("No CSV imported") }
    var candles by remember { mutableStateOf<List<Candle>>(emptyList()) }
    var importMessage by remember { mutableStateOf("Import a candle CSV to begin research.") }
    var isLoading by remember { mutableStateOf(false) }
    var rr by remember { mutableFloatStateOf(2f) }
    var backtest by remember { mutableStateOf<BacktestResult?>(null) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        screenshotUri = it
    }
    val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            isLoading = true
            scope.launch {
                try {
                    val result = withContext(Dispatchers.IO) { CsvImporter.read(context, uri) }
                    candles = result.second
                    csvName = result.first
                    importMessage = "Imported ${result.second.size} candles successfully."
                } catch (e: Exception) {
                    importMessage = "Import failed: ${e.message ?: "Check CSV format"}"
                } finally { isLoading = false }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Dark, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Dark,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("AURUM INTELLIGENCE", fontWeight = FontWeight.Bold)
                            Text("ANDROID RESEARCH EDITION  •  v0.3", style = MaterialTheme.typography.labelSmall, color = Gold)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Dark)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Overview", "Screenshot", "CSV Lab", "Backtest").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(
                                when(i) { 0 -> Icons.Default.Dashboard; 1 -> Icons.Default.Image; 2 -> Icons.Default.TableChart; else -> Icons.Default.Analytics },
                                contentDescription = label
                            ) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> Overview(Modifier.padding(padding), candles.size, screenshotUri != null)
                1 -> ScreenshotScreen(Modifier.padding(padding), screenshotUri,
                    onPick = { imagePicker.launch("image/*") })
                2 -> CsvScreen(Modifier.padding(padding), csvName, candles, importMessage, isLoading,
                    onPick = { csvPicker.launch(arrayOf("text/*", "text/csv", "application/vnd.ms-excel")) })
                else -> BacktestScreen(Modifier.padding(padding), candles, rr, { rr = it }, backtest) { backtest = ResearchBacktester.run(candles, rr.toDouble()) }
            }
        }
    }
}

@Composable
fun Page(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
}
@Composable
fun PanelCard(title: String, body: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold)
            body()
        }
    }
}
@Composable
fun Overview(modifier: Modifier, count: Int, hasImage: Boolean) = Page(modifier) {
    Text("Gold Research Console", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Text("Research from your own Exness MT5 chart captures and exported historical candles.")
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard("CSV candles", count.toString(), Modifier.weight(1f))
        StatCard("Chart image", if (hasImage) "Added" else "Not added", Modifier.weight(1f))
    }
    PanelCard("System status") {
        StatusLine("MT5 direct connection", "Not connected — Android-only mode")
        StatusLine("Local CSV research", if (count > 0) "Data loaded" else "Waiting for data")
        StatusLine("Live order execution", "Disabled")
    }
    PanelCard("How to start") {
        Text("1. MT5 Android mein XAUUSD chart open karein aur screenshot lein.")
        Text("2. Screenshot tab mein image select karein.")
        Text("3. MT5 desktop/web export se CSV file hasil kar ke CSV Lab mein import karein.")
        Text("4. Research tab mein candle statistics aur breakout sample dekhein.")
    }
    Text("Important: Screenshot interpretation is visual assistance, not verified tick data or a guaranteed trading signal.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
}
@Composable
fun StatCard(label: String, value: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Color.LightGray, style = MaterialTheme.typography.labelMedium)
            Text(value, color = Gold, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}
@Composable
fun StatusLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
    }
}
@Composable
fun ScreenshotScreen(modifier: Modifier, uri: Uri?, onPick: () -> Unit) = Page(modifier) {
    Text("MT5 Screenshot Analyzer", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Text("Select an XAUUSD chart screenshot from your phone.")
    Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp)); Text("Choose chart screenshot")
    }
    if (uri != null) {
        AsyncImage(model = uri, contentDescription = "Selected MT5 chart", modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 420.dp), contentScale = ContentScale.Fit)
        PanelCard("Image review checklist") {
            Text("• Confirm symbol is XAUUSD.")
            Text("• Identify timeframe and visible price scale.")
            Text("• Mark swing highs/lows, possible liquidity pools and displacement.")
            Text("• Check for BOS/CHoCH, FVG and order-block context.")
            Text("No automatic AI vision inference is included in this offline starter; this screen stores and previews the selected image.")
        }
    } else PanelCard("Waiting for screenshot") { Text("Your selected chart image will appear here.") }
}
@Composable
fun CsvScreen(modifier: Modifier, name: String, candles: List<Candle>, message: String, loading: Boolean, onPick: () -> Unit) = Page(modifier) {
    Text("Historical CSV Lab", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Button(onClick = onPick, modifier = Modifier.fillMaxWidth(), enabled = !loading) {
        Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(8.dp)); Text(if (loading) "Importing..." else "Import CSV file")
    }
    PanelCard("Import status") {
        Text(name, color = Gold)
        Text(message)
        Text("Accepted columns: time/date, open, high, low, close; optional volume.")
    }
    if (candles.isNotEmpty()) {
        PanelCard("Dataset preview") {
            Text("${candles.size} candles • ${candles.first().time} to ${candles.last().time}")
            candles.takeLast(5).asReversed().forEach {
                Text("${it.time}  O ${it.open}  H ${it.high}  L ${it.low}  C ${it.close}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
@Composable
fun ResearchScreen(modifier: Modifier, candles: List<Candle>) = Page(modifier) {
    Text("Quant Research", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    if (candles.size < 3) {
        PanelCard("Waiting for dataset") { Text("Import at least 3 valid candles to calculate basic statistics.") }
    } else {
        val bullish = candles.count { it.close > it.open }
        val bearish = candles.count { it.close < it.open }
        val rangeAvg = candles.map { it.high - it.low }.average()
        val breakoutUp = candles.zipWithNext().count { (a,b) -> b.close > a.high }
        val breakoutDown = candles.zipWithNext().count { (a,b) -> b.close < a.low }
        PanelCard("Dataset statistics") {
            StatusLine("Total candles", candles.size.toString())
            StatusLine("Bullish candles", "$bullish (${pct(bullish,candles.size)}%)")
            StatusLine("Bearish candles", "$bearish (${pct(bearish,candles.size)}%)")
            StatusLine("Average candle range", "%.5f".format(Locale.US, rangeAvg))
        }
        PanelCard("Previous-candle breakout sample") {
            Text("Close above previous high: $breakoutUp")
            Text("Close below previous low: $breakoutDown")
            Text("These are raw event counts, not a strategy win rate. No future outcome, spread or slippage model is applied yet.")
        }
        PanelCard("Research limitations") {
            Text("• No claim of profitability.")
            Text("• Dataset timeframe and broker timezone must be checked.")
            Text("• Avoid combining different timeframes in one dataset.")
            Text("• This starter does not place trades.")
        }
    }
}
fun pct(a: Int, b: Int) = if (b == 0) "0.0" else "%.1f".format(Locale.US, a * 100.0 / b)


data class BacktestResult(
    val trades: Int, val wins: Int, val losses: Int, val skipped: Int,
    val netR: Double, val winRate: Double, val maxDrawdownR: Double
)

object ResearchBacktester {
    // Signal: close above prior high = long; close below prior low = short.
    // Entry: next candle open. Stop: signal candle's opposite extreme.
    // If stop and target occur in the same candle, count stop first.
    fun run(data: List<Candle>, rr: Double): BacktestResult {
        if (data.size < 4) return BacktestResult(0,0,0,0,0.0,0.0,0.0)
        var wins=0; var losses=0; var skipped=0
        var net=0.0; var equity=0.0; var peak=0.0; var dd=0.0
        var i=1
        while (i < data.size-1) {
            val signal=data[i]; val prev=data[i-1]
            val long=signal.close > prev.high
            val short=signal.close < prev.low
            if (!long && !short) { i++; continue }
            val entry=data[i+1].open
            val stop=if(long) signal.low else signal.high
            val risk=if(long) entry-stop else stop-entry
            if(risk<=0) { skipped++; i++; continue }
            val target=if(long) entry+risk*rr else entry-risk*rr
            var result:Double?=null; var exit=i+1; var j=i+1
            while(j<data.size) {
                val bar=data[j]
                val hitStop=if(long) bar.low<=stop else bar.high>=stop
                val hitTarget=if(long) bar.high>=target else bar.low<=target
                if(hitStop) { result=-1.0; exit=j; break }
                if(hitTarget) { result=rr; exit=j; break }
                j++
            }
            if(result==null) { skipped++; i++; continue }
            net+=result; equity+=result; peak=maxOf(peak,equity); dd=maxOf(dd,peak-equity)
            if(result>0) wins++ else losses++
            i=maxOf(i+1,exit)
        }
        val n=wins+losses
        return BacktestResult(n,wins,losses,skipped,net,if(n==0) 0.0 else wins*100.0/n,dd)
    }
}

@Composable
fun BacktestScreen(
    modifier: Modifier, candles: List<Candle>, rr: Float,
    onRr: (Float)->Unit, result: BacktestResult?, onRun: ()->Unit
) = Page(modifier) {
    Text("Breakout Backtest", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
    Text("Rule: candle closes above previous candle high = long; below previous low = short.")
    PanelCard("Configuration") {
        Text("Risk : Reward 1 : ${"%.1f".format(Locale.US,rr)}", color=Gold)
        Slider(value=rr,onValueChange=onRr,valueRange=1f..5f,steps=7)
        Text("Entry: next candle open • Stop: signal candle extreme")
        Text("Same-candle stop/target collision is conservatively counted as a stop.")
        Button(onClick=onRun,enabled=candles.size>=4,modifier=Modifier.fillMaxWidth()) {
            Icon(Icons.Default.PlayArrow,null); Spacer(Modifier.width(6.dp)); Text("Run backtest (${candles.size} candles)")
        }
    }
    if(candles.size<4) PanelCard("Dataset required") { Text("Import at least four candles in CSV Lab.") }
    result?.let {
        PanelCard("Results") {
            StatusLine("Closed trades",it.trades.toString())
            StatusLine("Wins / Losses","${it.wins} / ${it.losses}")
            StatusLine("Win rate","${"%.1f".format(Locale.US,it.winRate)}%")
            StatusLine("Net result","${"%.2f".format(Locale.US,it.netR)} R")
            StatusLine("Maximum drawdown","${"%.2f".format(Locale.US,it.maxDrawdownR)} R")
            StatusLine("Unresolved / skipped",it.skipped.toString())
        }
        Text("Research prototype only. Excludes spread, commission, slippage, swaps, gaps and tick-level execution. These results are not a prediction or proof of profitability.",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)
    }
}

object CsvImporter {
    suspend fun read(context: android.content.Context, uri: Uri): Pair<String, List<Candle>> {
        val rows = mutableListOf<Candle>()
        val fileName = uri.lastPathSegment ?: "Imported CSV"
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open selected file" }
            BufferedReader(InputStreamReader(input)).useLines { lines ->
                val all = lines.filter { it.isNotBlank() }.toList()
                require(all.size >= 2) { "CSV must contain a header and candle rows" }
                val header = splitCsv(all.first()).map { it.trim().lowercase(Locale.US) }
                fun idx(vararg names: String) = header.indexOfFirst { h -> names.any { h == it } }
                val ti = idx("time", "date", "datetime", "timestamp")
                val oi = idx("open"); val hi = idx("high"); val li = idx("low"); val ci = idx("close")
                val vi = idx("volume", "tick_volume", "tick volume")
                require(listOf(ti,oi,hi,li,ci).all { it >= 0 }) {
                    "Required headers: time/date, open, high, low, close"
                }
                all.drop(1).forEachIndexed { lineNo, line ->
                    val c = splitCsv(line)
                    try {
                        val o = c[oi].toDouble(); val h = c[hi].toDouble()
                        val l = c[li].toDouble(); val cl = c[ci].toDouble()
                        require(h >= maxOf(o,cl,l) && l <= minOf(o,cl,h)) { "Invalid OHLC values" }
                        rows.add(Candle(c[ti], o, h, l, cl, if (vi >= 0) c.getOrNull(vi)?.toDoubleOrNull() else null))
                    } catch (e: Exception) {
                        throw IllegalArgumentException("Invalid data near CSV row ${lineNo + 2}: ${e.message}")
                    }
                }
            }
        }
        require(rows.isNotEmpty()) { "No valid candle rows found" }
        return fileName to rows
    }
    private fun splitCsv(line: String): List<String> {
        val out = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
        while (i < line.length) {
            val ch = line[i]
            if (ch == '"') {
                if (quoted && i + 1 < line.length && line[i+1] == '"') { cell.append('"'); i++ }
                else quoted = !quoted
            } else if (ch == ',' && !quoted) { out.add(cell.toString()); cell.clear() }
            else cell.append(ch)
            i++
        }
        out.add(cell.toString())
        return out
    }
}
