# v0.3 status
- [x] Android dashboard, screenshot picker and preview
- [x] OHLC CSV import and validation
- [x] Basic candle statistics
- [x] Configurable breakout backtest with R-multiple reporting
- [ ] Automatic screenshot AI/OCR and ICT/SMC recognition
- [ ] Persistent local database
- [ ] Spread/slippage/commission modelling and walk-forward validation
- [ ] APK build and Android device testing

Source project only; not a compiled or device-tested APK.
