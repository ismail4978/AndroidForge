# AURUM INTELLIGENCE Android Research Edition v0.3

## Added
- Screenshot picker and preview (manual visual review; no automatic AI/OCR yet).
- CSV OHLC import from phone storage.
- Basic candle statistics.
- Configurable previous-candle breakout backtest (RR 1:1 to 1:5).
- Entry on next candle open; stop at signal candle's opposite extreme.
- Conservative same-candle collision handling: stop is counted first.

## CSV format
Required headers: `time` (or date/datetime), `open`, `high`, `low`, `close`.
Optional: `volume`. Use comma delimiters and decimal points. One symbol and one timeframe per file.

## Build
Open in Android Studio (JDK 17, Android SDK 35), sync Gradle, then Build > Build Bundle(s)/APK(s) > Build APK(s).
APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Not yet included
- Direct Exness MT5 connection or live prices.
- Automatic chart image recognition, OCR or AI vision.
- Permanent local database (CSV dataset is currently held in app memory).
- Spread, commission, slippage, swaps, gap and tick-level modelling.
- Walk-forward validation, multi-timeframe management and order execution.

This is source code, not a compiled or device-tested APK. Backtest output is a simplified research estimate, not a trading recommendation.

## Phone se APK build
`BUILD_APK_FROM_ANDROID_PHONE_UR.md` mein GitHub Actions ke zariye Android phone se APK banane ke steps diye gaye hain. Workflow `.github/workflows/build-apk.yml` mein hai.
